package com.task8;

import java.util.List;

public class Question {
    private String questionText;
    private List<String> options;
    private int correctOptionIndex; 

    public Question(String questionText, List<String> options, int correctOptionIndex) {
        this.questionText = questionText;
        this.options = options;
        this.correctOptionIndex = correctOptionIndex;
    }

    public String getQuestionText() {
        return questionText;
    }

    public List<String> getOptions() {
        return options;
    }

    public boolean isCorrect(int chosenOptionIndex) {
        return chosenOptionIndex == correctOptionIndex;
    }

    public int getCorrectOptionIndex() {
        return correctOptionIndex;
    }
}